﻿using Microsoft.AspNetCore.Mvc;

namespace BitirmeOdev.Controllers
{
    public class DefaultController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
