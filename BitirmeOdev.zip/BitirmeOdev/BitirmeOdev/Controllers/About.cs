﻿using Microsoft.AspNetCore.Mvc;

namespace BitirmeOdev.Controllers
{
    public class About : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
