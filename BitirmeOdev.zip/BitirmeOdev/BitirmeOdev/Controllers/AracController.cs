﻿using Microsoft.AspNetCore.Mvc;

namespace BitirmeOdev.Controllers
{
    public class AracController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
