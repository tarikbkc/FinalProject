﻿using System;

namespace EntityLayer.Concrete
{
    internal class keyAttribute : Attribute
    {
    }
}