﻿namespace BusinessLayer.Concrete
{
    public interface IAboutServices
    {
    }
}